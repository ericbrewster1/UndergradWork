Name: Eric Brewster
Section: 10860 (Kidane)
UFL email: ericbrewster@ufl.edu
System: Windows
Compiler: g++
SFML version: 2.5.1 (I think)
IDE: CLion
Other notes: None